# Security Policy

## Our Commitment

Jordan Intelligence is a cybersecurity platform. Security is not just a feature for us — it is the entire foundation of what we build. We take every security report seriously and respond with urgency.

## Supported Versions

| Version | Supported |
|---|---|
| Latest (main branch) | ✅ Fully supported |
| Previous releases | ⚠️ Critical fixes only |

## Reporting a Vulnerability

**Please do not report security vulnerabilities through public GitHub issues.**

If you discover a security vulnerability in Jordan Intelligence — whether in the platform code, client dashboard, admin system, or any other component — please report it responsibly using one of the following methods:

### Option 1 — GitHub Private Vulnerability Reporting (Preferred)
Use GitHub's built-in private vulnerability reporting:
1. Go to the **Security** tab of this repository
2. Click **"Report a vulnerability"**
3. Fill out the form with as much detail as possible

### Option 2 — Direct Contact
Open a **private** issue marked `[SECURITY]` in the title and request that maintainers respond privately before any public disclosure.

## What to Include in Your Report

To help us respond as quickly as possible, please include:

- **Description** of the vulnerability and its potential impact
- **Steps to reproduce** the issue (be as specific as possible)
- **Affected component** (landing page, signup, dashboard, admin panel, etc.)
- **Your environment** (browser, operating system, device type)
- **Proof of concept** if you have one (screenshots, code, video)
- **Your suggested fix** if you have ideas

## What Happens After You Report

| Timeline | Action |
|---|---|
| **Within 24 hours** | We acknowledge receipt of your report |
| **Within 72 hours** | We provide an initial assessment and severity rating |
| **Within 7 days** | We communicate our remediation plan |
| **Upon fix deployment** | We notify you and credit you (if desired) |

## Severity Ratings

We use the following severity levels:

| Level | Description | Examples |
|---|---|---|
| 🔴 **Critical** | Immediate threat to client data or platform integrity | Auth bypass, data exposure, remote code execution |
| 🟠 **High** | Significant security impact requiring urgent attention | XSS, CSRF, privilege escalation |
| 🟡 **Medium** | Security issue with limited impact | Information disclosure, weak validation |
| 🟢 **Low** | Minor security concern | Non-sensitive information exposure |

## Safe Harbor

Jordan Intelligence will not take legal action against researchers who:

- Report vulnerabilities through the proper channels described above
- Do not access, modify, or delete client data
- Do not disrupt platform operations or client services
- Do not publicly disclose the vulnerability before we have addressed it
- Act in good faith throughout the disclosure process

## Recognition

We appreciate the security community. Researchers who responsibly disclose valid vulnerabilities will be:

- Acknowledged in our security changelog (with your permission)
- Given credit in the relevant fix commit or release notes
- Contacted for potential bug bounty arrangements on critical findings

## Out of Scope

The following are outside the scope of our vulnerability disclosure program:

- Social engineering or phishing attacks targeting Jordan Intelligence staff
- Physical security issues
- Denial of service attacks
- Issues in third-party services (Stripe, Supabase, Vercel) — report those directly to the respective vendors
- Issues requiring physical access to a client's device

---

*Jordan Intelligence — Security is our product. We hold ourselves to the highest standard.*

**Last updated:** 2025
