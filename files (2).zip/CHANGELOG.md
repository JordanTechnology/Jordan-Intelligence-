# Changelog

All notable changes to Jordan Intelligence are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.0.0] — 2025-05-30 — Initial Public Release

### Added

**Platform Core**
- `index.html` — Full public landing page with live threat ticker, all four pricing plans, feature breakdown, how-it-works section, trust bar, and call-to-action
- `signup.html` — Client account creation with plan selection (Personal Shield, Business Starter, Business Pro, Enterprise Fortress), 30-day free trial messaging, and form validation
- `dashboard.html` — Complete client portal with live threat feed, AI engine health display, quick actions, reports, device management, alert settings, and direct support messaging
- `admin.html` — Owner control center with client roster, revenue by tier, Stripe payout information, tax set-aside calculator, earnings projection calculator, support inbox, platform-wide threat feed, and system status

**Jordan Intelligence Branding**
- Custom gear-and-circuit SVG logo built from scratch matching the Jordan Intelligence brand identity
- Deep navy + cyan + steel blue color palette pulled from brand logo
- Rajdhani display font for headings and data (high-contrast, tech-forward)
- Barlow body font for readable descriptions and interface text
- Consistent brand voice throughout: plain English, no jargon, accessible to everyone

**Four-Tier Pricing System**
- Personal Shield — $9/month for individuals and families
- Business Starter — $49/month for small businesses
- Business Pro — $149/month for large businesses
- Enterprise Fortress — $499/month for enterprise and institutions

**AI Engine Display**
- Live threat detection metrics (pattern recognition, behavioral analysis, threat prediction, auto-adaptation)
- Real-time threat counter updating every few seconds
- Human-sense AI module cards explaining intent detection, evolving memory, context reasoning, and predictive strike
- Live platform-wide threat feed with severity classification (Critical, High, Medium, Low)

**Revenue and Business Tools**
- Revenue breakdown by all four client tiers in admin panel
- Stripe fee calculation (2.9% + $0.30 per transaction)
- Tax set-aside recommendation (28% of net revenue)
- Earnings calculator with live sliders for all four tiers
- Monthly and annual take-home projections

**GitHub Repository Structure**
- `README.md` — Complete professional documentation with all platform details
- `LICENSE` — Proprietary license protecting all platform code and assets
- `SECURITY.md` — Vulnerability disclosure policy and reporting procedures
- `CONTRIBUTING.md` — Contributor guide with code standards and PR process
- `CODE_OF_CONDUCT.md` — Community standards for all contributors and users
- `CHANGELOG.md` — This file
- `.github/ISSUE_TEMPLATE/bug_report.md` — Structured bug reporting template
- `.github/ISSUE_TEMPLATE/feature_request.md` — Structured feature request template
- `.github/PULL_REQUEST_TEMPLATE.md` — Pull request checklist and standards
- `_config.yml` — GitHub Pages configuration

**Technical Foundation**
- Zero external framework dependencies — pure HTML5, CSS3, and Vanilla JavaScript
- CSS custom properties (variables) for full theme consistency
- Mobile-responsive layout across all four pages
- localStorage-based session management connecting signup → dashboard
- Live counters updating in real time across all pages
- Animated scan line, grid background, and live ticker on landing page

---

## Roadmap — Upcoming Releases

### [1.1.0] — Stripe Integration
- Connect real Stripe payment processing to signup flow
- Live subscription management in admin panel
- Automatic billing emails to clients
- Revenue data pulling from Stripe API directly

### [1.2.0] — Supabase Backend
- Real client database replacing localStorage
- Persistent accounts across devices
- Admin panel showing real signup data in real time
- Email verification on account creation

### [1.3.0] — Real AI Threat Engine
- Connect Anthropic Claude API for threat analysis
- Real network monitoring integration
- Actual threat detection and blocking logic
- AI-generated plain-English reports

### [1.4.0] — Mobile Apps
- iOS app built with Expo
- Android app built with Expo
- Push notifications for threat alerts
- Biometric login support

### [1.5.0] — Twilio Alerts
- SMS notifications for critical threats
- Email alerts using SendGrid
- Weekly digest emails auto-generated
- Monthly report PDFs auto-generated and delivered

### [2.0.0] — Enterprise Features
- White-label deployment system
- Custom AI model training per enterprise client
- On-premise deployment option
- Full compliance report generation (HIPAA, SOC2)
- Multi-user admin accounts for large organizations

---

*Jordan Intelligence — Always on. Always adapting. Always protecting.*
