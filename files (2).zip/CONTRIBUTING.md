# Contributing to Jordan Intelligence

Thank you for your interest in contributing to Jordan Intelligence. This document outlines the process for contributing to this project and what we expect from contributors.

## Before You Start

Jordan Intelligence is a **proprietary commercial platform**. All contributions become the property of Jordan Intelligence upon submission. By contributing, you agree that:

- Your contribution will be licensed under the Jordan Intelligence Proprietary License
- You have the right to submit the contribution (it is your original work)
- You are not violating any agreements with your employer or other parties

## What We Welcome

We welcome contributions in the following areas:

### 🐛 Bug Reports
Found something broken? Please report it. Good bug reports include:
- A clear description of what you expected to happen
- A clear description of what actually happened
- Steps to reproduce the issue
- Your browser, operating system, and device
- Screenshots or screen recordings if applicable

### 💡 Feature Suggestions
Have an idea that would make Jordan Intelligence better for individuals, small businesses, large businesses, or enterprise clients? We want to hear it. Good feature requests include:
- A clear description of the problem you are trying to solve
- Your proposed solution
- Which client tier would benefit most from this feature
- Any examples of similar features you have seen elsewhere

### 🔧 Code Improvements
If you are a developer and want to contribute code:
- Bug fixes for documented issues
- Performance improvements
- Accessibility improvements
- Mobile responsiveness enhancements
- Code cleanup and documentation

## How to Contribute

### Step 1 — Open an Issue First
Before writing any code, open an issue describing what you want to do. This lets us:
- Confirm the change is something we want to include
- Avoid duplicate work
- Give you guidance on the best approach

### Step 2 — Fork the Repository
1. Click **Fork** at the top right of this repository
2. Clone your fork locally:
```bash
git clone https://github.com/YOUR-USERNAME/Jordan-Intelligence-.git
cd Jordan-Intelligence-
```

### Step 3 — Create a Branch
Always work on a new branch, never directly on `main`:
```bash
git checkout -b fix/description-of-your-fix
# or
git checkout -b feature/description-of-your-feature
```

**Branch naming conventions:**
- `fix/` — for bug fixes
- `feature/` — for new features
- `docs/` — for documentation changes
- `style/` — for UI/CSS changes with no logic changes
- `perf/` — for performance improvements

### Step 4 — Make Your Changes
Keep your changes focused. One pull request should address one thing. If you are fixing a bug and notice another unrelated bug, open a separate issue for it.

**Code standards we follow:**
- Clean, readable HTML5 with semantic elements
- CSS using the established variable system (see `:root` in any page file)
- Vanilla JavaScript — no new framework dependencies
- Comments for anything non-obvious
- Mobile-first responsive design
- All text accessible (proper contrast ratios, readable font sizes)

### Step 5 — Test Your Changes
Before submitting, test your changes:
- Open each modified page in Chrome, Safari, and Firefox
- Test on both desktop and mobile screen sizes
- Verify all navigation links still work
- Verify the signup flow still works end-to-end
- Check that the admin panel still renders all client data correctly

### Step 6 — Commit Your Changes
Write clear commit messages:
```bash
# Good
git commit -m "Fix mobile navigation overflow on signup page"
git commit -m "Add password strength indicator to signup form"
git commit -m "Improve contrast ratio on threat feed severity badges"

# Not helpful
git commit -m "fix stuff"
git commit -m "updates"
git commit -m "changes"
```

### Step 7 — Submit a Pull Request
1. Push your branch to your fork
2. Open a pull request against the `main` branch of this repository
3. Fill out the pull request template completely
4. Link to the issue your PR addresses

## Pull Request Standards

Every pull request must include:

- **Clear title** describing what the PR does
- **Description** of the changes made and why
- **Screenshots** if there are any visual changes (before and after)
- **Testing notes** — what you tested and how
- **Issue reference** — link to the issue this PR closes

## Code of Conduct

See [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md) for our full community standards.

The short version: be respectful, be constructive, help each other. We are building something that protects real people. Take that seriously.

## Review Process

All pull requests will be reviewed before merging. Reviews typically happen within 3–5 business days. You may be asked to make changes before your PR is accepted. This is normal — do not take it personally.

We look at every PR for:
- Does it solve the stated problem without introducing new ones?
- Is the code clean and consistent with the existing codebase?
- Does it maintain or improve the user experience?
- Does it maintain security standards?

## Questions?

If you have questions about contributing, open a discussion in the **Issues** tab with the label `question`. We are happy to help.

---

*Every improvement to Jordan Intelligence helps protect real people. Thank you for contributing.*
