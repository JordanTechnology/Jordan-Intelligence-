# Code of Conduct

## Our Pledge

Jordan Intelligence is built to protect everyone — individuals, families, small businesses, large companies, and enterprise organizations. The same principle applies to how we run this community. Everyone who participates in this project — contributors, users, reporters, and maintainers — deserves to be treated with respect and dignity.

We pledge to make participation in Jordan Intelligence a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, gender identity and expression, level of experience, nationality, personal appearance, race, religion, or sexual identity and orientation.

## Our Standards

### Behavior We Encourage

- Using welcoming and inclusive language
- Being respectful of differing viewpoints and experiences
- Accepting constructive criticism gracefully
- Focusing on what is best for the platform and the people it protects
- Showing empathy toward other community members
- Giving credit where it is due
- Helping newcomers get started

### Behavior We Do Not Tolerate

- Harassment of any kind, public or private
- Trolling, insulting, or derogatory comments
- Personal or political attacks
- Publishing private information about others without consent
- Sexual language or imagery of any kind
- Deliberate intimidation or threats
- Any conduct that would be considered inappropriate in a professional setting

## Our Responsibilities

Project maintainers are responsible for clarifying the standards of acceptable behavior and are expected to take appropriate and fair corrective action in response to any instances of unacceptable behavior.

Maintainers have the right and responsibility to remove, edit, or reject comments, commits, code, issues, and other contributions that do not align with this Code of Conduct, and to temporarily or permanently ban any contributor for behaviors they deem inappropriate, threatening, offensive, or harmful.

## Scope

This Code of Conduct applies within all project spaces — the GitHub repository, issue tracker, pull requests, discussions, and any other official Jordan Intelligence communication channels. It also applies when an individual is officially representing the project in public spaces.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by opening a private issue or contacting the project maintainers directly through GitHub. All complaints will be reviewed and investigated promptly and fairly. All reports will be kept confidential.

Maintainers who do not follow or enforce this Code of Conduct may face temporary or permanent repercussions as determined by other members of the project leadership.

## Consequences

**1st offense:** Private written warning with clarification of the violation and expectations going forward.

**2nd offense:** Temporary ban from all project interaction for a period determined by maintainers.

**3rd offense or severe violation:** Permanent ban from all project spaces.

## Attribution

This Code of Conduct is adapted from the Contributor Covenant, version 2.1, available at https://www.contributor-covenant.org/version/2/1/code_of_conduct.html

---

*Jordan Intelligence — Protecting everyone starts with how we treat each other.*
